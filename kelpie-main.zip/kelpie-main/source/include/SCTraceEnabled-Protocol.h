#import <Foundation/Foundation.h>
@protocol SCTraceEnabled <NSObject>
@end

