@interface SCSwipeViewContainerViewController: NSObject
@property NSUInteger allowedDirections;
@end
