#include <UIKit/UIKit.h>
#include <Foundation/Foundation.h>

@interface SCStatusBarOverlayLabelWindow : UIWindow
+(void)showErrorWithText:(id)arg1 backgroundColor:(id)arg2;
+(void)showMessageWithText:(id)arg1 backgroundColor:(id)arg2;
@end
