@interface SCMapBitmojiCluster:NSObject
@property CLLocationCoordinate2D centerCoordinate;
@end
