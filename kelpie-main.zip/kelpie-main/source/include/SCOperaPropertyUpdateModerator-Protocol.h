#import <Foundation/Foundation.h>

@class NSDictionary;

@protocol SCOperaPropertyUpdateModerator <NSObject>
- (void)didUpdateViewProperties:(NSDictionary *)arg1;
@end

