





@class NSArray;
@protocol SCContextActionMenuDataSource;

@protocol SCContextActionMenuDataSourceDelegate
- (void)actionMenuDataSource:(id <SCContextActionMenuDataSource>)arg1 didUpdateActionMenuItems:(NSArray *)arg2;
@end

