#define CDUnknownBlockType id
