#import <Foundation/Foundation.h>

@class SIGHeaderEditingTextField;

@protocol SIGHeaderEditingTextFieldDelgate <NSObject>
- (void)SIGHeaderEditingTextFieldDidResign:(SIGHeaderEditingTextField *)arg1;
@end

