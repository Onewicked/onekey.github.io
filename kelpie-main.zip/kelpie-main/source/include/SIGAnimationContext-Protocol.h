#import <Foundation/Foundation.h>

@protocol SIGAnimationContext <NSObject>
- (void)completeAnimation:(_Bool)arg1;
@end

