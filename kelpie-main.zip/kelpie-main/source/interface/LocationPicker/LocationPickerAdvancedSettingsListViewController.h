#import <UIKit/UIKit.h>
@interface LocationPickerAdvancedSettingsListViewController : UIViewController{
    UITableView * _table;
}

-(UITableView *)table;

@end
